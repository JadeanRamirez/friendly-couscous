install.packages("usethis")
library(usethis)
use_course("http://bit.ly/getting-started-with-r")
3
